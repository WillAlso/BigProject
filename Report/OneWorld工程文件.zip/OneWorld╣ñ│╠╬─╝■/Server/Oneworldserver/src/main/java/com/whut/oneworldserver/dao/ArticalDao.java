package com.whut.oneworldserver.dao;

import com.whut.oneworldserver.bean.ArticalInfo;

import java.util.List;

public interface ArticalDao {
    List<ArticalInfo> getAllArtical();
}
