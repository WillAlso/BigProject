package com.whut.oneworldserver.service;


import com.whut.oneworldserver.bean.ArticalInfo;

import java.util.List;

public interface ArticalService {
    List<ArticalInfo> getAllArtical();
}
