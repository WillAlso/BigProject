package com.whut.oneworldserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneworldserverApplicationTests {

    @Test
    void contextLoads() {
    }

}
