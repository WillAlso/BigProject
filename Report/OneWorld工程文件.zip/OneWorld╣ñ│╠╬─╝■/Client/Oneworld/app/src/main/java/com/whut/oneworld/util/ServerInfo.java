package com.whut.oneworld.util;

public class ServerInfo {
    public final static String BASE_URL = "http://192.168.1.102:8080/";
    public final static String MY_USERINFO = "userinfo";
}
