package com.whut.oneworld.bean.detectbean;

public class ResultOne {
    String log_id;
    ResultTwo result;

    public String getLog_id() {
        return log_id;
    }

    public void setLog_id(String log_id) {
        this.log_id = log_id;
    }

    public ResultTwo getResult() {
        return result;
    }

    public void setResult(ResultTwo result) {
        this.result = result;
    }
}
