package com.whut.oneworld.bean.detectbean;

import java.util.List;

public class DetectBean {
    ResultOne nameValuePairs;

    public ResultOne getNameValuePairs() {
        return nameValuePairs;
    }

    public void setNameValuePairs(ResultOne nameValuePairs) {
        this.nameValuePairs = nameValuePairs;
    }
}
