package com.whut.oneworld.bean.detectbean;

public class Baike_info{
    BaikeDetail nameValuePairs;

    public BaikeDetail getNameValuePairs() {
        return nameValuePairs;
    }

    public void setNameValuePairs(BaikeDetail nameValuePairs) {
        this.nameValuePairs = nameValuePairs;
    }
}
