package com.whut.oneworld.bean.detectbean;

public class Value {
    ValueInfo nameValuePairs;

    public ValueInfo getNameValuePairs() {
        return nameValuePairs;
    }

    public void setNameValuePairs(ValueInfo nameValuePairs) {
        this.nameValuePairs = nameValuePairs;
    }
}
