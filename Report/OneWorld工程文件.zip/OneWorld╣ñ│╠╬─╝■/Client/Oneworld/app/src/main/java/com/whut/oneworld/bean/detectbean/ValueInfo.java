package com.whut.oneworld.bean.detectbean;

public class ValueInfo {
    double score;
    String name;
    Baike_info baike_info;

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Baike_info getBaike_info() {
        return baike_info;
    }

    public void setBaike_info(Baike_info baike_info) {
        this.baike_info = baike_info;
    }
}
