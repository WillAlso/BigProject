package com.whut.oneworld.bean.detectbean;

import java.util.List;

public class ResultTwo {
    List<Value> values;

    public List<Value> getValues() {
        return values;
    }

    public void setValues(List<Value> values) {
        this.values = values;
    }
}
